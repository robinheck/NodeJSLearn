function welcome() {
  return `Hello!`;
}

welcome();
