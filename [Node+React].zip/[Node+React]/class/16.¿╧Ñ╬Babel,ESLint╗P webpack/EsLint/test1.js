var test1 = 'This is a not used var!';

function test2() {
    var message = 'ＨＩＨＩ!';
    alert(message);
}

test2();