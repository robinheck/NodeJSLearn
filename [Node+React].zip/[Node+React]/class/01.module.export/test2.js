var Me = require('./test1.js');

/* 1 */
//Me.name();

// /* 2 */
//console.log(Me);

/* 3 */
console.log(Me.type);
console.log(Me);