/* 1 */
exports.name = function () { 
  console.log('I am banana')  
};

/* 2 */
exports.hi = function () { 
  console.log('hihi')  
};

// /* 3 */
module.exports = {
  type: 'string',
  text: 'hihi'
}


//注意:如果寫出了module.exports 會忽略掉上面寫的exports.hi 跟 exports.name