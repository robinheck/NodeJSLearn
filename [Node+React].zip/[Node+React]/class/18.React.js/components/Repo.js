import React, { Component } from 'react'

const Repo = (props) => (
  <div>{props.params.repoName}</div>
);

export default Repo