import React, { Component } from 'react'

const Proptest = () => (
  <div>Proptest</div>
);

export default Proptest